package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.RetestDto;
import com.cg.exception.RetestException;
import com.cg.service.RetestService;
import com.cg.service.RetestServiceImpl;


@WebServlet("*.do")
public class RetestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    RetestService service=new RetestServiceImpl();
RetestDto dto=new RetestDto();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		String path=request.getServletPath();
		System.out.println(path);
		String price=null;
		String decAmt=null;
		double priceDouble=0.0;
		double price2=0.0;
		HttpSession session=request.getSession(true);
		if(path.equals("/insert.do"))
		{
			
			
			System.out.println(session.getId());
			String name=request.getParameter("uname");
			System.out.println(name);
			 price=request.getParameter("tamt");
		System.out.println(price);
			 priceDouble=Double.parseDouble(price);
			dto.setName(name);
			dto.setTotalPrice(priceDouble);
			try {
				int status=service.addEmployee(dto);
				session.setAttribute("dto", dto);
				RequestDispatcher dispatch=request.getRequestDispatcher("welcome.jsp");
				dispatch.forward(request, response);
			} catch (RetestException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(path.equals("/minus.do"))
		{
			decAmt=request.getParameter("damt");
			price2=Double.parseDouble(decAmt);
			priceDouble=dto.getTotalPrice();
			System.out.println(priceDouble);
			System.out.println(price2);
			double finalAmt=priceDouble-price2;
			session.setAttribute("finalAmt", finalAmt);
			System.out.println(finalAmt);
			RequestDispatcher dispatch=request.getRequestDispatcher("minus.jsp");
			dispatch.forward(request, response);
		}
		
		
	}
}
