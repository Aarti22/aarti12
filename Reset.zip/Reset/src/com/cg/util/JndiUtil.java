package com.cg.util;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Author		:	vandana nagpal
 * Class Name	:	JndiUtil
 * Package		:	com.capgemini.electricity.util
 * Date			:	14-Mar-2017
 */

public class JndiUtil {

	static Connection conn=null;
	public static Connection obtainConnection() 
	{
		InitialContext context;
		try {
			context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS2"); //jdbc/ConPool
			conn=source.getConnection();
		} catch (NamingException e) {
			
			e.printStackTrace();
			//throw new EmployeeException("Problem in Connection");
		} catch (SQLException e) {
			
			e.printStackTrace();
			//throw new EmployeeException("Problem in Connection");
		}
		
		return conn;
		
	}

	}



