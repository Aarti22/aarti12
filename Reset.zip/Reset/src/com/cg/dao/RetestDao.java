package com.cg.dao;

import com.cg.dto.RetestDto;
import com.cg.exception.RetestException;



public interface RetestDao {
	public  int addEmployee(RetestDto dto) throws RetestException;
}
