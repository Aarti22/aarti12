package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;


import java.sql.SQLException;


import com.cg.dto.RetestDto;
import com.cg.exception.RetestException;
import com.cg.util.JndiUtil;

public class RetestDaoImpl implements RetestDao{
	Connection conn=null;
	PreparedStatement ps=null;
	@Override
	public int addEmployee(RetestDto dto) throws RetestException {
		String query="INSERT INTO RETEST VALUES(?,?)";
		try {System.out.println("in fucntion");
			conn=JndiUtil.obtainConnection();
			ps=conn.prepareStatement(query);
			ps.setString(1, dto.getName());
		ps.setDouble(2, dto.getTotalPrice());
			int status=	ps.executeUpdate();
			System.out.println(status);
			if(status==1)
			{
				
				System.out.println("data inserted ");
			}
			
			} catch (SQLException e) {
				
				e.printStackTrace();
				throw new RetestException("Data Not inserted");
			}
			finally
			{
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
					throw new RetestException("In Finally");
				}
	
			
}//end of finaally
		return 1;
	}
}
