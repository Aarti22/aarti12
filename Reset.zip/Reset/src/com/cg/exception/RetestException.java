package com.cg.exception;

public class RetestException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public RetestException() {
		
	}

	public RetestException(String message) {
		super(message);
	
	}

	public RetestException(Throwable cause) {
		super(cause);
		
	}

	public RetestException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public RetestException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}
}
