package com.cg.service;

import com.cg.dto.RetestDto;
import com.cg.exception.RetestException;

public interface RetestService {
	public  int addEmployee(RetestDto dto) throws RetestException;
}
