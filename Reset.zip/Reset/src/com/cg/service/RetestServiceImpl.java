package com.cg.service;


import com.cg.dao.RetestDao;
import com.cg.dao.RetestDaoImpl;
import com.cg.dto.RetestDto;
import com.cg.exception.RetestException;

public class RetestServiceImpl implements RetestService {
	RetestDao empDao;
	public RetestServiceImpl()
	{
		empDao=new RetestDaoImpl();
	}
	@Override
	public int addEmployee(RetestDto dto) throws RetestException {
		
		return empDao.addEmployee(dto);
	}

	

}
