package com.cg.dto;

public class RetestDto {

	private String name;
	private Double TotalPrice;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getTotalPrice() {
		return TotalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		TotalPrice = totalPrice;
	}
	public RetestDto(String name, Double totalPrice) {
		super();
		this.name = name;
		TotalPrice = totalPrice;
	}
	public RetestDto() {
		super();
	}
	@Override
	public String toString() {
		return "RetestDto [name=" + name + ", TotalPrice=" + TotalPrice + "]";
	}
	

}
